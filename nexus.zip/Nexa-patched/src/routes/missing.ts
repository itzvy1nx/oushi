import type { Hono } from "hono";

export default function (app: Hono) {
  // Endpoints Fortnite 24.20 asks for during lobby boot.
  // Returning safe empty/default responses prevents client-side network kicks caused by 404s.

  app.post("/publickey/v1/publickey", (c) => c.json([]));

  app.get("/party/api/v1/Fortnite/user/:accountId", (c) =>
    c.json({
      current: [],
      pending: [],
      invites: [],
      pings: [],
    }),
  );

  app.get("/party/api/v1/Fortnite/user/:accountId/settings/privacy", (c) =>
    c.json({ privacy: "PUBLIC" }),
  );

  app.get("/party/api/v1/Fortnite/user/:accountId/notifications/undelivered/count", (c) =>
    c.json({ count: 0 }),
  );

  app.get("/friends/api/v1/:accountId/summary", (c) =>
    c.json({
      friends: [],
      incoming: [],
      outgoing: [],
      blocklist: [],
      suggested: [],
    }),
  );

  app.get("/api/v1/lfg/Fortnite/users/:accountId/settings", (c) => c.json({}));
  app.get("/api/v2/interactions/latest/Fortnite/:accountId", (c) => c.json([]));
  app.get("/statsproxy/api/statsv2/account/:accountId", (c) => c.json({}));
  app.get("/api/v1/links/history/:accountId", (c) => c.json([]));
  app.get("/api/v1/public/accounts", (c) => c.json([]));
  app.get("/fortnite/api/game/v2/br-inventory/account/:accountId", (c) => c.json({}));
  app.get("/api/content/v2/launch-data", (c) => c.json({}));
  app.get("/app_installation/status", (c) => c.json({ status: "installed" }));
  app.get("/region", (c) => c.json({ region: "NAE" }));

  app.put("/profile/play_region", (c) => c.json({ region: "NAE" }));
  app.put("/profile/languages", (c) => c.json({}));
  app.put("/profile/privacy_settings", (c) => c.json({}));

  app.get("/links/api/fn/mnemonic/playlist_defaultsolo", (c) =>
    c.json({
      namespace: "fn",
      accountId: "epic",
      mnemonic: "playlist_defaultsolo",
      linkType: "BR:Playlist",
      metadata: {
        playlistName: "Playlist_DefaultSolo",
      },
      version: 1,
      active: true,
      disabled: false,
      created: new Date().toISOString(),
      published: new Date().toISOString(),
      descriptionTags: [],
      moderationStatus: "Unmoderated",
    }),
  );
}
