import { Hono } from "hono";
import path from "node:path";
import { loadRoutes } from "./utils/startup/loadRoutes";
import { Nexa } from "./utils/handlers/errors";
import logger from "./utils/logger/logger";
import { cors } from "hono/cors";

const app = new Hono({ strict: false });

app.use("*", cors());

app.notFound((c) => c.json(Nexa.basic.notFound, 404));

app.use(async (c, next) => {
  if (c.req.path === "/images/icons/gear.png" || c.req.path === "/favicon.ico") await next();
  else {
    await next();

    logger.backend(`${c.req.path} | ${c.req.method} | Status ${c.res.status}`);
  }
});

await loadRoutes(path.join("src", "routes"), app);

// Simple Fortnite matchmaking WebSocket.
// Nexa returned ws://...:5555 but never actually listened on 5555.
// This gives the client the StatusUpdate -> SessionAssignment flow it expects.
const PUBLIC_IP = "172.190.162.70";
const GAME_PORT = 7777;

try {
  Bun.serve({
    port: 5555,
    fetch(req, server) {
      if (server.upgrade(req)) return;
      return new Response("Nexa matchmaking websocket", { status: 200 });
    },
    websocket: {
      open(ws) {
        const sessionId = crypto.randomUUID().replace(/-/g, "");
        const send = (name: string, payload: any = {}) => {
          try {
            ws.send(JSON.stringify({ name, payload }));
          } catch {}
        };

        send("StatusUpdate", { state: "Connecting" });
        setTimeout(() => send("StatusUpdate", { state: "Waiting", totalPlayers: 1, connectedPlayers: 1 }), 250);
        setTimeout(() => send("StatusUpdate", { state: "Queued", ticketId: sessionId, queuedPlayers: 1, estimatedWaitSec: 0 }), 500);
        setTimeout(() =>
          send("StatusUpdate", {
            state: "SessionAssignment",
            matchId: sessionId,
            sessionId,
            joinDelaySec: 1,
          }), 900);
        setTimeout(() =>
          send("Play", {
            matchId: sessionId,
            sessionId,
            joinDelaySec: 1,
            serverAddress: PUBLIC_IP,
            serverPort: GAME_PORT,
          }), 1200);
      },
      message(ws, message) {
        // Keep the socket alive; Fortnite may send pings/control messages here.
        try {
          if (typeof message === "string" && message.toLowerCase().includes("ping")) ws.send("pong");
        } catch {}
      },
    },
  });

  logger.backend("Matchmaking websocket started on port 5555");
} catch (err) {
  logger.error(`Failed to start matchmaking websocket on 5555: ${(err as Error).message}`);
}

logger.backend("Nexa started on port 5353");

export default {
  port: 5353,
  fetch: app.fetch,
}